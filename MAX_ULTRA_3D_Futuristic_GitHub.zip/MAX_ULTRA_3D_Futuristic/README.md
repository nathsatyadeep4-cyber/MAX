# MAX ULTRA — 3D Futuristic Calculator

Responsive neon-red/purple/blue calculator with a depth-styled 3D HUD interface.

## Run
Open `index.html` in a modern browser.

## GitHub Pages
Upload `index.html` and `README.md` to a GitHub repository, then choose **Settings → Pages → Deploy from a branch → main → /(root)**.

## Working features
- Scientific arithmetic: +, −, ×, ÷, parentheses, powers, square root, percent, sin/cos/tan, log, ln, π and e
- Keyboard support
- Percentage and discount helper
- EMI estimator
- Unit converter
- Quadratic equation solver, including complex roots
- Binary, octal, decimal and hexadecimal conversion
- Calculation history
- 3D-inspired depth, layered neon lighting, floating HUD accent, raised keys and responsive layout

Trigonometric functions use radians. AI, camera OCR, symbolic calculus and true 3D graphing are not included in this version.
