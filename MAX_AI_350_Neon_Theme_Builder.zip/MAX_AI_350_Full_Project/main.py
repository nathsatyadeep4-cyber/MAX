import os, json, datetime, webbrowser, threading
from pathlib import Path
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup

APP_NAME = "MAX AI"
BG=(0.015,0.025,0.055,1); PANEL=(0.035,0.075,0.13,1); BLUE=(0.0,0.55,1.0,1); TEXT=(0.88,0.96,1.0,1); MUTED=(0.40,0.72,0.90,1)

def get_data_dir():
    try:
        from android.storage import app_storage_path
        return Path(app_storage_path())
    except Exception:
        return Path.home()/".max_ai"
DATA=get_data_dir(); DATA.mkdir(parents=True, exist_ok=True)
def load(name, default):
    try: return json.loads((DATA/name).read_text(encoding="utf-8"))
    except Exception: return default
def save(name, value): (DATA/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")

def launch_package(package):
    try:
        from jnius import autoclass
        act=autoclass("org.kivy.android.PythonActivity").mActivity
        intent=act.getPackageManager().getLaunchIntentForPackage(package)
        if intent is None: return False
        intent.addFlags(0x10000000); act.startActivity(intent); return True
    except Exception: return False

class MaxRoot(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation="vertical",padding=dp(12),spacing=dp(8),**kw)
        self.memories=load("memories.json",[])
        self.reminders=load("reminders.json",[])
        self.settings=load("settings.json",{"api_base_url":"","api_key":""})
        self.catalog=load_catalog()
        self.status=Label(text="MAX ready • API can be configured later",size_hint_y=None,height=dp(26),color=MUTED,font_size="12sp")
        self.add_widget(self.make_header()); self.add_widget(self.status); self.show_home()

    def make_header(self):
        row=BoxLayout(size_hint_y=None,height=dp(56))
        title=Label(text="[b]M A X[/b]\\n[color=1685ff]PERSONAL AI ASSISTANT[/color]",markup=True,color=TEXT,halign="left")
        title.bind(size=lambda w,s:setattr(w,"text_size",s)); row.add_widget(title)
        b=Button(text="⚙ Settings",size_hint_x=None,width=dp(110),background_normal="",background_color=PANEL)
        b.bind(on_release=lambda *_:self.settings_popup()); row.add_widget(b)
        return row

    def set_status(self, text): self.status.text=text
    def clear_main(self):
        while len(self.children)>2: self.remove_widget(self.children[0])
    def show_home(self):
        self.clear_main()
        outer=BoxLayout(orientation="vertical",spacing=dp(8))
        outer.add_widget(Label(text="[b]MAX AI • Command Centre[/b]\\nVoice • Memory • Reminders • Automation • Tools",
                              markup=True,color=TEXT,size_hint_y=None,height=dp(70),font_size="18sp"))
        voice=Button(text="🎙 SPEAK COMMAND",size_hint_y=None,height=dp(52),background_normal="",background_color=BLUE)
        voice.bind(on_release=lambda *_:self.voice_once()); outer.add_widget(voice)
        grid=GridLayout(cols=2,spacing=dp(7),size_hint_y=None); grid.bind(minimum_height=grid.setter("height"))
        items=[
            ("📺 YouTube",lambda:self.open_app("com.google.android.youtube","https://youtube.com")),
            ("💬 WhatsApp",lambda:self.open_app("com.whatsapp","https://whatsapp.com")),
            ("🎮 BGMI",lambda:self.open_app("com.pubg.imobile",None)),
            ("📷 Camera",lambda:self.open_camera()),
            ("🧠 Memory Wallet",self.memory_popup),("⏰ Reminders",self.reminder_popup),
            ("🔄 Routines",self.routines_popup),("🌐 Web Search",self.search_popup),
            ("🧰 All Features",self.features_popup),("🔐 Permissions info",self.permissions_info)
        ]
        for label,fn in items:
            b=Button(text=label,size_hint_y=None,height=dp(58),background_normal="",background_color=PANEL,color=TEXT)
            b.bind(on_release=lambda _b,action=fn:action()); grid.add_widget(b)
        outer.add_widget(grid)
        scroll=ScrollView(); scroll.add_widget(outer); self.add_widget(scroll)

    def popup(self,title,widget,height=dp(400)):
        p=Popup(title=title,content=widget,size_hint=(.94,None),height=height,separator_color=BLUE)
        p.open(); return p

    def voice_once(self):
        # Use Android speech recognizer UI instead of covert always-on recording.
        try:
            from jnius import autoclass
            act=autoclass("org.kivy.android.PythonActivity").mActivity
            Intent=autoclass("android.content.Intent")
            RI=autoclass("android.speech.RecognizerIntent")
            intent=Intent(RI.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(RI.EXTRA_LANGUAGE_MODEL,RI.LANGUAGE_MODEL_FREE_FORM)
            intent.putExtra(RI.EXTRA_PROMPT,"Speak a command for MAX")
            intent.putExtra(RI.EXTRA_LANGUAGE,"en-IN")
            act.startActivityForResult(intent,7251)
            self.set_status("Android speech UI opened. Command-result callback needs native bridge integration.")
        except Exception:
            self.set_status("Voice UI requires Android build and speech services. Use typed command below.")
            self.command_popup()

    def command_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(8))
        inp=TextInput(hint_text="Type a command: hey max open youtube",multiline=False,size_hint_y=None,height=dp(48))
        btn=Button(text="Run command",size_hint_y=None,height=dp(44),background_normal="",background_color=BLUE)
        box.add_widget(inp); box.add_widget(btn); p=self.popup("MAX Command",box,dp(180))
        btn.bind(on_release=lambda *_:(p.dismiss(),self.handle_command(inp.text)))

    def handle_command(self,command):
        c=command.lower().replace("hey max","").strip()
        if "open youtube" in c: self.open_app("com.google.android.youtube","https://youtube.com")
        elif "open whatsapp" in c: self.open_app("com.whatsapp","https://whatsapp.com")
        elif "open bgmi" in c or "open pubg" in c: self.open_app("com.pubg.imobile",None)
        elif "open camera" in c: self.open_camera()
        elif c.startswith("remember "): self.add_memory(c[9:].strip())
        elif c.startswith("search "): self.web_search(c[7:])
        elif "time" in c: self.set_status(datetime.datetime.now().strftime("Time: %I:%M %p"))
        elif "date" in c: self.set_status(datetime.date.today().strftime("Date: %d %B %Y"))
        elif "reminder" in c: self.reminder_popup()
        elif "memory" in c: self.memory_popup()
        else: self.set_status("Command not built in. Configure an AI API later for open-ended AI answers.")

    def open_app(self,package,fallback):
        if launch_package(package): self.set_status("Launching "+package); return
        if fallback: webbrowser.open(fallback); self.set_status("App launch unavailable; opened web fallback.")
        else: self.set_status("App not installed or launch blocked.")
    def open_camera(self):
        try:
            from jnius import autoclass
            act=autoclass("org.kivy.android.PythonActivity").mActivity
            Intent=autoclass("android.content.Intent"); act.startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            self.set_status("Camera opened.")
        except Exception: self.set_status("Camera launch requires Android build.")

    def add_memory(self,text):
        if not text: return
        self.memories.append({"text":text,"created":datetime.datetime.now().isoformat(timespec="minutes")})
        save("memories.json",self.memories); self.set_status("Memory saved.")
    def memory_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(6))
        inp=TextInput(hint_text="What should MAX remember?",size_hint_y=None,height=dp(72))
        box.add_widget(inp)
        b=Button(text="Save memory",size_hint_y=None,height=dp(42),background_normal="",background_color=BLUE)
        box.add_widget(b)
        scroll=ScrollView(); rows=BoxLayout(orientation="vertical",size_hint_y=None,spacing=dp(4)); rows.bind(minimum_height=rows.setter("height"))
        for item in reversed(self.memories[-60:]):
            rows.add_widget(Label(text="• "+item.get("text",""),size_hint_y=None,height=dp(38),color=TEXT,halign="left"))
        scroll.add_widget(rows); box.add_widget(scroll); p=self.popup("Memory Wallet",box,dp(440))
        b.bind(on_release=lambda *_:(self.add_memory(inp.text.strip()),p.dismiss(),self.memory_popup()))
    def reminder_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(6))
        title=TextInput(hint_text="Reminder title",multiline=False,size_hint_y=None,height=dp(44))
        when=TextInput(hint_text="Optional time, e.g. 2026-10-10 18:30",multiline=False,size_hint_y=None,height=dp(44))
        box.add_widget(title); box.add_widget(when)
        b=Button(text="Add reminder",size_hint_y=None,height=dp(42),background_normal="",background_color=BLUE); box.add_widget(b)
        scroll=ScrollView(); rows=BoxLayout(orientation="vertical",size_hint_y=None); rows.bind(minimum_height=rows.setter("height"))
        for r in reversed(self.reminders[-40:]):
            rows.add_widget(Label(text=("✓ " if r.get("done") else "• ")+r.get("title","")+" "+r.get("when",""),size_hint_y=None,height=dp(36),color=TEXT))
        scroll.add_widget(rows); box.add_widget(scroll); p=self.popup("Reminders",box,dp(430))
        def add(*_):
            if title.text.strip():
                self.reminders.append({"title":title.text.strip(),"when":when.text.strip(),"done":False})
                save("reminders.json",self.reminders); p.dismiss(); self.set_status("Reminder saved locally; scheduled Android notifications need native alarm integration.")
        b.bind(on_release=add)
    def routines_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(6))
        for name,desc in [("Sleep","DND / brightness / Bluetooth actions need supported Android access."),
                          ("Morning","Daily status and app shortcuts."),
                          ("Work","Focus routine template."),
                          ("Gaming","Gaming routine template.")]:
            b=Button(text=name+"\\n"+desc,size_hint_y=None,height=dp(72),background_normal="",background_color=PANEL)
            b.bind(on_release=lambda _b,n=name:self.set_status(n+" routine selected; device actions are not all implemented."))
            box.add_widget(b)
        self.popup("Routines",box,dp(370))
    def web_search(self,query):
        webbrowser.open("https://www.google.com/search?q="+query.strip().replace(" ","+"))
        self.set_status("Opened web search.")
    def search_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(8))
        inp=TextInput(hint_text="Search the web",multiline=False,size_hint_y=None,height=dp(46))
        b=Button(text="Search",size_hint_y=None,height=dp(42),background_normal="",background_color=BLUE)
        box.add_widget(inp); box.add_widget(b); p=self.popup("Web Search",box,dp(170))
        b.bind(on_release=lambda *_:(p.dismiss(),self.web_search(inp.text)))
    def features_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(5))
        search=TextInput(hint_text="Filter feature names",multiline=False,size_hint_y=None,height=dp(42))
        box.add_widget(search); scroll=ScrollView(); rows=BoxLayout(orientation="vertical",size_hint_y=None,spacing=dp(3)); rows.bind(minimum_height=rows.setter("height"))
        def populate(*_):
            rows.clear_widgets(); q=search.text.lower()
            for f in self.catalog.get("features",[]):
                if q and q not in f["name"].lower() and q not in f["category"].lower(): continue
                rows.add_widget(Label(text=f'{f["id"]}. [{f["category"]}] {f["name"]} — {f["status"]}',
                                      size_hint_y=None,height=dp(36),color=TEXT,halign="left",valign="middle"))
        search.bind(text=populate); populate(); scroll.add_widget(rows); box.add_widget(scroll)
        self.popup("All MAX Features",box,dp(520))
    def settings_popup(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(8))
        box.add_widget(Label(text="Add API later. Never share a real API key or hard-code it into a public APK.",color=MUTED))
        url=TextInput(text=self.settings.get("api_base_url",""),hint_text="AI API base URL",multiline=False,size_hint_y=None,height=dp(44))
        key=TextInput(text=self.settings.get("api_key",""),hint_text="AI API key (optional)",password=True,multiline=False,size_hint_y=None,height=dp(44))
        b=Button(text="Save settings",size_hint_y=None,height=dp(42),background_normal="",background_color=BLUE)
        box.add_widget(url); box.add_widget(key); box.add_widget(b); p=self.popup("MAX Settings",box,dp(270))
        def store(*_):
            self.settings={"api_base_url":url.text.strip(),"api_key":key.text.strip()}
            save("settings.json",self.settings); p.dismiss(); self.set_status("API settings saved locally; API calls are not wired yet.")
        b.bind(on_release=store)
    def permissions_info(self):
        self.popup("Android Permissions",Label(text="Microphone, camera, overlay, notifications, contacts, SMS and accessibility need native Android configuration and user-granted access. Android restrictions still apply.",color=TEXT),dp(230))

def load_catalog():
    try:
        path=Path(__file__).with_name("feature_catalog.json")
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return {"feature_count":0,"features":[]}

class MaxApp(App):
    def build(self):
        self.title=APP_NAME; Window.clearcolor=BG
        return MaxRoot()
if __name__=="__main__": MaxApp().run()
