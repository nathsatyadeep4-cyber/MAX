# Feature status

## Implemented baseline
- Kivy dashboard and feature catalogue browser
- Basic command router (YouTube, WhatsApp, BGMI, Camera, time/date, remember, search)
- Local JSON Memory Wallet
- Local JSON reminders list (not scheduled Android alarms)
- Routines screen templates
- API settings placeholders, saved locally
- Web search launch
- Android package launch hooks (must be tested in Android build)

## Scaffold / requires more implementation
The catalogue marks most advanced features as `scaffold_or_requires_native_api`. This includes always-on wake word, background foreground service, overlay window, scheduled notifications, native permission workflows, AI API calls, image generation, notification listener/auto-reply, calls/SMS, device controls, PC companion, encryption validation and system-level automation.

Android may restrict microphone use, calls, SMS, background execution, overlay and accessibility. Use visible user-controlled permissions and notifications. Do not assume a feature works just because it appears in the catalogue.
