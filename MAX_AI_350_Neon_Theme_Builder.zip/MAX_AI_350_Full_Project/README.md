# MAX AI — Python Android Project

Feature catalogue count: 350 entries across voice, overlay, app control, AI, camera/vision, communications, Android controls, routines, reminders, memory, weather, web search, PC bridge, privacy, UI, background reliability and diagnostics.

## Files
- `main.py`: Kivy app UI, local memory/reminder storage, basic commands and settings.
- `feature_catalog.json`: full feature catalogue with implementation status.
- `buildozer.spec`: Buildozer Android packaging configuration.
- `requirements.txt`: Python dependencies.
- `FEATURE_STATUS.md`: honest status of what works vs needs native implementation.

## Run on desktop
Install Python 3.10+, then:
```bash
python -m pip install -r requirements.txt
python main.py
```
Some Android-specific features will not work on desktop.

## Build Android APK
On Linux/WSL:
```bash
python -m pip install buildozer
buildozer android debug
```
GitHub Actions workflow is included at `.github/workflows/build.yml`. Push/commit the project to GitHub, then open Actions and download the `MAX-AI-APK` artifact if the build succeeds. APK build has not been verified in this environment.

## Important
This is a large starter/scaffold and feature catalogue, not a claim that all listed capabilities are already fully functional. Local memory, reminders list, basic command routing, web search, settings and basic app-launch hooks are implemented. Always-on wake word, foreground microphone service, floating overlay service, Android alarm notifications, accessibility automation, actual AI API requests, image generation, auto-reply, PC bridge, calls/SMS and many device controls require further native Android/service integration. API URL/key fields are placeholders so you can add your provider later.
