[app]
title = MAX AI
package.name = maxai
package.domain = org.maxassistant
source.dir = .
source.include_exts = py,json,kv,png,jpg,txt,md
version = 1.0.0
requirements = python3,kivy,pyjnius
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,RECORD_AUDIO,CAMERA,POST_NOTIFICATIONS
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
